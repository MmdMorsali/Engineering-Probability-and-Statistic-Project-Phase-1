#!/usr/bin/env python
# coding: utf-8

# In[67]:


#simulation 12

import numpy as np
import random
from numpy.linalg import eig
from sklearn.cluster import SpectralClustering
from sklearn.datasets.samples_generator import make_blobs
import matplotlib.pyplot as plt


random.seed(10)
n=500
p=0.1
q=0.01


def randbin(M,N,P):
    return np.random.choice( [0 , 1] , size =(M,N) , p=[1-P , P] )

g = randbin(1,n,0.5)[0]

A = np.zeros([n,n])
W = np.zeros([n,n])
D_A = np.zeros([n,n])
D_W = np.zeros([n,n])

for i in range(n):
    for j in range(i):
        if(i==j):
            A[i][j]=0
            W[i][j]=p
        else:
            if (g[i]==g[j]):
                A[i][j]=randbin(1,1,p)[0]
                A[j][i]=A[i][j]
                W[i][j]=p
                W[j][i]=W[i][j]
            else :
                A[i][j]=randbin(1,1,q)[0]
                A[j][i]=A[i][j]
                W[i][j]=q
                W[j][i]=W[i][j]
                

da_ii = A.sum(axis=1)
dw_ii = W.sum(axis=1)

for i in range (n):
    D_A[i][i]=da_ii[i]
    D_W[i][i]=dw_ii[i]

L_A = D_A - A
L_W = D_W - W

w_A,v_A=eig(L_A)
w_W,v_W=eig(L_W)


print(A)
print(W)
print(D_A)
print(D_W)
print(L_A)
print(L_W)
print(v_A)
print(v_W)

x_A, _ = make_blobs(n_samples=n, centers=1, cluster_std=2)
x_W, _ = make_blobs(n_samples=n, centers=1, cluster_std=2)
for i in range(n):
    x_A[i][0]=v_A[0][i]
    x_A[i][1]=v_A[1][i]
    
    x_W[i][0]=v_W[0][i]
    x_W[i][1]=v_W[1][i]

    
    
print(x_A)
print(x_W)


plt.figure(1)
plt.subplot(211)
plt.scatter(x_A[:,0], x_A[:,1])
plt.show()

plt.figure(2)
plt.subplot(211)
plt.scatter(x_W[:,0], x_W[:,1])
plt.show()


# In[3]:


#simulation 13

import numpy as np
import random
from numpy.linalg import eig
from sklearn.cluster import SpectralClustering
from sklearn.datasets.samples_generator import make_blobs
import matplotlib.pyplot as plt


random.seed(10)
p=0.1
q=0.01


def randbin(M,N,P):
    return np.random.choice( [0 , 1] , size =(M,N) , p=[1-P , P] )


for n in range (500,1000,500):
        g = randbin(1,n,0.5)[0]

        A = np.zeros([n,n])
        W = np.zeros([n,n])
        D_A = np.zeros([n,n])
        D_W = np.zeros([n,n])

        for i in range(n):
            for j in range(i):
                if(i==j):
                    A[i][j]=0
                    W[i][j]=p
                else:
                    if (g[i]==g[j]):
                        A[i][j]=randbin(1,1,p)[0]
                        A[j][i]=A[i][j]
                        W[i][j]=p
                        W[j][i]=W[i][j]
                    else :
                        A[i][j]=randbin(1,1,q)[0]
                        A[j][i]=A[i][j]
                        W[i][j]=q
                        W[j][i]=W[i][j]


        da_ii = A.sum(axis=1)
        dw_ii = W.sum(axis=1)

        for i in range (n):
            D_A[i][i]=da_ii[i]
            D_W[i][i]=dw_ii[i]

        L_A = D_A - A
        L_W = D_W - W

        w_A,v_A=eig(L_A)
        w_W,v_W=eig(L_W)


        print(A)
        print(W)
        print(D_A)
        print(D_W)
        print(L_A)
        print(L_W)
        print(v_A)
        print(v_W)

        x_A, _ = make_blobs(n_samples=n, centers=1, cluster_std=1)
        x_W, _ = make_blobs(n_samples=n, centers=1, cluster_std=1)
        for i in range(n):
            x_A[i][0]=v_A[0][i]
            x_A[i][1]=v_A[1][i]

            x_W[i][0]=v_W[0][i]
            x_W[i][1]=v_W[1][i]



        print(x_A)
        print(x_W)


        plt.figure(1)
        plt.subplot(211)
        plt.scatter(x_A[:,0], x_A[:,1])
        plt.show()

        plt.figure(2)
        plt.subplot(211)
        plt.scatter(x_W[:,0], x_W[:,1])
        plt.show()

        # !/usr/bin/env python
        # coding: utf-8

        # # Simulation 2

        # In[1]:

        import numpy as np
        import random
        import matplotlib.pyplot as plt
        import networkx as nx


        # <p dir="rtl">
        #
        # در این بخش از ما خواسته شده است تا  ده عدد ماتریس مجاورت تولید و نمایش دهیم که با استفاده از محاسبات تئوری مقدار احتمال رابطه بین افراد را که برابر با 0.225 است به تابع rand bin داده و به عنوان خروجی ده ماتریس مجاورت تحویل می گیریم
        # </p>

        # In[2]:

        def randbin(M, N, P):
            return np.random.choice([0, 1], size=(M, N), p=[1 - P, P])


        random.seed(956832962)
        for i in range(10):
            print(randbin(15, 15, 0.225))


        # # Simulation 3
        #

        # <p dir="rtl">
        #     در این بخش از ما خواسته شده است که یک نمونه از ماتریس مجاورت را با استفاده از تابع rand bin بسازیم و گراف مورد نظر برای روابط آن را نمایش دهیم مشخص است در شکل گراف هیچ راس منفردی وجود ندارد
        # </p>

        # In[3]:

        def myPlotFunction(B):
            G = nx.DiGraph()
            for i in range(15):
                for j in range(15):
                    if B[i][j] == 1:
                        G.add_edge(i, j, weight=1)
            nx.draw_shell(G, with_labels=True, font_weight='bold', node_color='orange')
            plt.show()


        B = randbin(15, 15, 0.225)
        G = myPlotFunction(B)


        # # Simulation 4

        # <p dir="rtl">
        #  در این پرسش از ما خواسته شده است که دو بردار z1 , z2 رو به تابعی پاس داده و خروجی فاصله همینگ این دو بردار باشد(تعداد درایه هایی که با هم دیگر متفاوت اند)
        # </p>

        # In[4]:

        def hammingDistance(z1, z2):
            c = 0
            for i in range(len(z1)):
                if z1[i] != z2[i]:
                    c = c + 1
            return (c)


        # In[5]:

        z1 = list(map(int, input("enter your first list:").split()))
        z2 = list(map(int, input("enter your first list:").split()))
        print("Hamming Dictance of two vector is :", hammingDistance(z1, z2))


        #
        # # Simulation 5

        # <p dir="rtl">
        #  در این پرسش از ما خواسته شده است که کمینه فاصله همینگ یک بردار را مستقل از نام خوشه بدست آوریم برای همین موضوع لازم است که جایگشت های بردار مد نظر را محاسبه نموده و کمترین فاصله همینگ میان دو بردار را با استفاده از تابعی که در شبیه سازی قبلی تعریف کردیم به دست آوریم
        #
        # </p>

        # In[6]:

        def permutation(lst):
            if len(lst) == 0:
                return []

            if len(lst) == 1:
                return [lst]

            l = []

            for i in range(len(lst)):
                m = lst[i]

                remLst = lst[:i] + lst[i + 1:]

                for p in permutation(remLst):
                    l.append([m] + p)
            return l


        def minHamming(data1, data2):
            c = np.inf
            for p in permutation(data1):
                for k in permutation(data2):
                    if c > hammingDistance(p, k):
                        c = hammingDistance(p, k)
                        res = [p, k]
            print("Minimum Haming Distace is :" + str(c))


        # In[7]:

        data1 = list(map(int, input("enter your first list:").split()))
        data2 = list(map(int, input("enter your first list:").split()))
        minHamming(data1, data2)


        # # Simulation 6

        # <p dir='rtl'>
        # در این بخش از ما خواسته شده است که لگاریتم L(z)  که برابر با احتمال ماتریس مجاورت به شرط بردار z است را محاسبه کنیم
        #
        # </p>

        # In[8]:

        def lz(C, z0):
            p2 = 1
            for i in range(0, len(z0)):
                p1 = 1
                for j in range(i + 1, len(z0)):
                    if z0[j] == z0[i]:
                        if C[i, j] == 0:
                            p1 *= 0.4
                        else:
                            p1 *= 0.6

                    else:
                        if C[i, j] == 0:
                            p1 *= 0.9
                        else:
                            p1 *= 0.1

                p2 *= p1

            return -1 * np.log10(p2), p2


        # In[15]:

        C = randbin(15, 15, 0.225)  # this matrix will call in next Simulations
        z0 = [3, 1, 2, 1, 3, 1, 2, 2, 2, 3, 3, 2, 1, 1, 3]
        a, b = lz(C, z0)
        print("L(z):" + str(a))


        # # Simulation 7

        # <p dir='rtl'>
        #
        # در این بخش از ما خواسته شده است که الگوریتم ارائه شده را پیاده سازی کنیم
        # برای این کار از تابعی استفاده میکنیم که توانایی خاصی در دادن جایگشت ها به ما دارد و مانند تابع استفاده شده  برای جایگشت در بخش قبلی نیست برای این کار محدودیتی برای تعداد جایگشت های خواسته شده می گذاریم و آن هم این موضوع است که
        # وقتی تعداد المان های یک بردار بیشتر می شود تعداد جایگشت های ما نیز بیشتر خواهد شد و توابعی ما توانایی پردازش آن همه جایگشت برای یک بردار با تعداد بالای درایه را ندارند(در صورت پروژه بردار مورد نظر 15 درایه دارد)
        #
        # </p>

        # In[16]:

        def ultraPermutation(B, N):
            ls = []
            ls.append(B)
            c = 0
            boolean = True
            for index, i in enumerate(B):
                if (boolean):
                    for j in range(index + 1, len(B)):
                        t = B.copy()  #
                        t = swap(t, index, j)
                        ls.append(t)
                        c = c + 1
                        if (c == N - 1):
                            boolean = False
                            break
                else:
                    break

            return ls


        def swap(list, ls1, ls2):

            list[ls1], list[ls2] = list[ls2], list[ls1]
            return list


        # In[17]:

        # main=[1,1,1,1,1,2,2,2,2,2,3,3,3,3,3]
        z1 = [1, 2, 3, 4]
        lst = ultraPermutation(z1, 3)
        lst


        # <p dir='rtl'>
        #     همان طور که خروجی سلول بالا مشخص است بردار z1 را به تابع ultraPermutation دادیم و خواستیم که تنها سه جایگشت از میان جایگشت های موجود را برای ما نمایش بدهد.
        # </p>

        # <p dir='rtl'>
        #     حال برای پیدا کردن کم ترین مقدار L(z) به ازای جایگشت های مختلف ومحدودی که داریم از تابعی استفاده می کنیم که ماتریس مجاورت A را ورودی گرفته و همچنین بردار ورودی z0 را ورودی می دهیم که به ازای جایگشت های مختلف آن که توسط ورودی N محدود شده است کمترین میزان L(z) را پیدا می کنیم و برای رسم نمودار از آن استفاده می کنیم
        # </p>

        # In[18]:

        def minLz(A, z0, N):
            lst = ultraPermutation(z0, N)
            temp = np.inf
            for i in (lst):
                a, b = lz(A, i)
                if a < temp:
                    temp = a
                    z1 = i
            print("Vector : ", z1)
            #  print("\n d(z0,z1) : ",calculate_dH(z0,z1))
            # print("\n minimum loss value : ",temp ,"\n")
            return temp


        # In[19]:

        B = randbin(15, 15, 0.225)
        z_0 = [1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3]
        minLz(B, z_0, 10)

        # In[20]:

        temp = np.inf
        z0 = []
        hamming = []
        loss = []
        for i in (lst):
            a, b = lz(C, i)
            loss.append(a)
            hamming.append(hammingDistance(i, z0))
            # print(a)
            if a < temp:
                temp = a
                z0 = i
        print(z0)
        # print(temp)
        print(loss)
        print(hamming)


        # <p dir='rtl'>
        # در نهایت به سراغ رسم نمودار می رویم
        #      و از روی شکل نمودار ها متوجه می شویم که فاصله همینگ بین 0 تا 2 جا به جا می شود.
        # </p>

        # In[21]:

        def plot(A, z0, N):
            lst = ultraPermutation(z0, N)
            y = []
            y2 = []
            x = []
            temp = np.inf
            for index, i in enumerate(lst):
                a, b = lz(A, i)
                x.append(index + 1)
                y.append(a)
                y2.append(hammingDistance(z0, i))
            fig = plt.figure(figsize=(20, 14))
            b = np.arange(23, 42, 1)
            b2 = np.arange(0, 2, 1)
            plt.subplot(211)
            plt.ylim(22, 35)
            plt.yticks(b)
            plt.xlabel(r"$t$ ", fontsize=18)
            plt.ylabel(r"$l(z)$", fontsize=18)
            plt.plot(x, y, '--o', color='y')
            plt.subplot(212)
            plt.ylim(-0.5, 2.5)
            plt.ylabel(r"$d(z_t,z_0)$", fontsize=16)
            plt.xlabel(r"$t$", fontsize=16)
            plt.yticks(b2)
            plt.plot(x, y2, '--o', '0', color='g')


        # In[22]:

        z_0 = [1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3]
        plot(B, z_0, 100)

        # # Simulation 8,9,10

        # <p dir='rtl'>
        #     در این بخش از ما خواسته شده است که به ازای ده بردار مختلف خروجی های بخش های قبلی رو دوباره تکرار کنیم و اگر نیاز بود نتایج را با هم مقایسه کنیم
        #
        # </p>

        # In[23]:

        lzList = [0] * 10

        # In[24]:

        z0 = [1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3]
        print(minLz(B, z0, 100))
        lst = ultraPermutation(z0, 10)
        print(lst)

        # <p dir='rtl'>
        #     در قسمت بالا با استفاده از تابعی که به تعدادی که میخواهیم به ما جایگشت یک بردار را می دهد به تعدادی جایگشت تولید می کنیم به ده جایگشت جدید برسیم(15 عدد تولید کرده ایم که تنها به 10 عدد آن ها نیازمندیم)
        #
        #
        # </p>

        # In[25]:

        lzList[0] = minLz(B, lst[0], 10)
        print(lzList[0])
        print(hammingDistance(z0, lst[0]))
        # print("Hamming Distance is :"+str(hammingDistance(z0,lst[0]))
        plot(B, lst[0], 100)

        # In[26]:

        lzList[0] = minLz(B, lst[1], 10)
        print(lzList[0])
        print(hammingDistance(z0, lst[1]))
        plot(B, lst[2], 100)

        # In[27]:

        lzList[1] = minLz(B, lst[1], 10)
        print(lzList[1])
        print(hammingDistance(z0, lst[1]))
        plot(B, lst[1], 100)

        # In[28]:

        lzList[2] = minLz(B, lst[2], 10)
        print(lzList[2])
        print(hammingDistance(z0, lst[2]))
        plot(B, lst[2], 100)

        # In[29]:

        lzList[3] = minLz(B, lst[3], 10)
        print(lzList[3])
        print(hammingDistance(z0, lst[3]))
        plot(B, lst[3], 100)

        # In[30]:

        lzList[4] = minLz(B, lst[4], 10)
        print(lzList[4])
        print(hammingDistance(z0, lst[4]))
        plot(B, lst[4], 100)

        # In[31]:

        lzList[5] = minLz(B, lst[5], 10)
        print(lzList[5])
        print(hammingDistance(z0, lst[5]))
        plot(B, lst[5], 100)

        # In[32]:

        lzList[6] = minLz(B, lst[6], 10)
        print(lzList[6])
        print(hammingDistance(z0, lst[6]))

        plot(B, lst[6], 100)

        # In[33]:

        lzList[7] = minLz(B, lst[7], 10)
        print(lzList[7])
        print(hammingDistance(z0, lst[7]))
        plot(B, lst[7], 100)

        # In[34]:

        lzList[8] = minLz(B, lst[8], 10)
        print(lst[8])
        print(z0)
        print(lzList[8])
        print(hammingDistance(z0, lst[8]))
        plot(B, lst[8], 100)

        # In[35]:

        lzList[9] = minLz(B, lst[9], 10)
        print(lzList[9])
        print(hammingDistance(z0, lst[9]))
        plot(B, lst[9], 100)

        # <p dir='rtl'>
        #     پس از بدست آوردن مقادیر لازمه متوجه می شویم که خروجی های ما وابسته به بردار اولیه هستند و به ازای هرورودی متفاوت یک خروجی متفاوت نیز خواهیم داشت
        #     (مرتبط با شبیه سازی 8)
        # </p>

        # <p dir='rtl'>
        #     بله طبق محاسبات به دست آمده حالتی وجود دارد که L(z0)  با باقی L(zi) ها برابر شود
        #     که خروجی فاصله همینگ کمینه بردارتخمین و z0 نیز چاپ شده است
        # </p>

        # <p dir='rtl'>
        #     همچنین طبق محاسبات انجام شده ممکن است j ای وجود داشته باشد که فاصله همینگ برابری داشته باشند
        #   البته با توجه به جایگشت های مختلف ممکن است مقدار فاصله همینگ غیرصفر شود
        # (مرتبط با شبیه سازی 10
        # </p>

        # # Simulation 11

        # <p dir='rtl'>
        #     درآخرین بخش شبیه سازی این سوال از ما خواسته شده است که دوماتریس مجاورت دیگر را به صورت رندوم تولید کنیم و هر کدام را به ازای N=10 مورد مختلف بررسی کنیم و بهترین نتیجه را گزارش کنیم
        #
        # </p>

        # In[69]:

        z0 = [1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3]
        L1 = lst.copy()
        L2 = lst.copy()
        print()

        # In[70]:

        R1 = randbin(15, 15, 0.225)
        R1

        # In[71]:

        R2 = randbin(15, 15, 0.225)
        R2

        # In[72]:

        L_z0 = minLz(R1, z_0, 100)
        print("L_z0:")
        print(L_z0)
        for i in range(10):
            print("L(z):" + str(minLz(R1, lst[i], 100)))

        # <p dir='rtl'>
        #     برای تخمین z0 باید نتیجه را به عنوان تخمین گر به دست آوریم که مقدار L(z) آن بردار نزدیک به L(z0) باشد
        #    z1,z2,z3,z4,z5,z8,z10 می باشند با توجه به خروجی ها به دست آمده بهترین بردار های برای تخمین بردارهای
        # </p>

        # In[75]:

        L_z0 = minLz(R2, z_0, 100)
        print("L_z0:")
        print(L_z0)
        for j in range(10):
            print("L(z):" + str(minLz(R2, lst[j], 100)))

        # <p dir='rtl'>
        #  به مانند به دست نتیجه گیری بدست آمده در بخش قبل باید گفت که بهترین بردارها برای تخمین z0 برابر با  و z1,z2,z3,z4,z5,z6,z10 هستند
        # </p>

        # <p dir='rtl'>
        # حال برای انتخابی یکی از دوبردار بدست آمده به عنوان تخمینی بهتر برای z0 باید به این موضوع توجه کنیم که هرچقدر  فاصله همینگ دوبردار با بردار اصلی کمتر باشد نتیجه بهتری به دست می آید.
        #     که با توجه به محاسبات که می توان با L(z) انجام داد متوجه می شویم که ماتریس اول کیس بهتری برای انجام عملیات است
        # </p>
# !/usr/bin/env python
# coding: utf-8

# In[48]:


import networkx as nx
import numpy as np

G = nx.karate_club_graph()
matA = np.arange(34 * 34).reshape(34, 34)

for i in range(0, 34):
    for j in range(0, 34):
        if (j in list(G[i].keys())):
            matA[i][j] = 1
        else:
            matA[i][j] = 0
matA

# In[49]:


matD = np.arange(34 * 34).reshape(34, 34)

for i in range(0, 34):
    matD[i][i] = len(G[i].keys())
    for j in range(0, 34):
        if (i != j):
            matD[i][j] = 0

matD

# In[61]:


matDinverse = np.linalg.inv(matD)
matDinverse
matP = matDinverse.dot(matA)
matP

# In[58]:


matP2 = matP.dot(matP)
matP2

# In[ ]:


# In[ ]:


# In[ ]:




#!/usr/bin/env python
# coding: utf-8

# In[25]:


import numpy as np

def log_likelihood(F, A):
    log_likelihood = 0
    for i in range(len(A)):
        for j in range(i+1,len(A[i])):
            if (A[i][j] == 0):
                log_likelihood -= np.inner(F[i],F[j])
            elif (A[i][j] == 1):
                log_likelihood += np.log(1-np.exp(np.inner(-F[i],F[j])))
    return log_likelihood

def gradient(F, A, i):
    gradient = 0
    for j in range(len(A[i])):
        if (i != j):
            if (A[i][j] == 0):
                gradient -= F[j]
            elif (A[i][j] == 1):
                gradient += (F[j]/(np.exp(np.inner(F[i],F[j]))-1))

    return gradient

def train(A, C, iterations = 200):
    # initialize an F
    N = A.shape[0]
    F = np.random.rand(N,C)

    for n in range(iterations):
        for person in range(N):
            grad = gradient(F, A, person)
            F[person] += 0.005*grad # updating F
            F[person] = np.maximum(0.001, F[person]) # F should be nonnegative
        ll = log_likelihood(F, A)
        print('At step %4i logliklihood is %5.4f'%(n,ll))

    return F


# In[27]:


import matplotlib.pyplot as plt
import networkx as nx
import numpy as np

#testing in two small groups
A=np.random.rand(40,40)
A[0:15,0:25]=A[0:15,0:25]>1- 0.6 # connection prob people with 1 common group
A[0:15,25:40]=A[0:15,25:40]>1-0.1 # connection prob people with no common group
A[15:40,25:40]=A[15:40,25:40]>1-0.7 # connection prob people with 1 common group
A[15:25,15:25]=A[15:25,15:25]>1-0.8 # connection prob people with 2 common group
for i in range(40):
    A[i,i]=0
    for j in range(i):
        A[i,j]=A[j,i]

#plt.imshow(A)
delta=np.sqrt(-np.log(1-0.1)) # epsilon=0.1
F=train(A, 2, iterations = 120)
print(F>delta)
G=nx.from_numpy_matrix(A)
C=F>delta # groups members
nx.draw(G,node_color=10*(C[:,0])+20*(C[:,1]))


# In[20]:


plt.imshow(A)


# In[ ]:


# !/usr/bin/env python
# coding: utf-8

# # 17

# In[77]:


import numpy as np
import scipy.stats as st

graph = np.zeros(1000 * 1000).reshape(1000, 1000)

m_list = []
for k in range(10):
    for i in range(0, 1000):
        for j in range(0, 1000):
            if (j > i):
                p = st.bernoulli.rvs(0.0034)
                graph[i][j] = p
                graph[j][i] = p
    m = np.count_nonzero(graph == 1)
    m_list.append(m)

s = sum(m_list)
mean_m = s / 10
print(m_list)
print(mean_m)

# In[2]:


# number of relations is half of m so we need to know mean_m/2
exm = mean_m / 2
exm

# <p dir="rtl">
#    همانطور که دیده میشود خروجی اولیه قبل از تقسیم بر 2 کردن (چون هر رابطه دوستی برای هر دو نفر حساب شده است و در نهایت تعداد روابط برابر با نصف خروجی است) که ما هم خروجی اولیه که 3419.2 بود را تقسیم بر 2 کردیم تا عدد 1697.3 که تعداد روابط دوستی است به دست آمد ولی احتمالا در سوال این تقسیم بر 2 کردن فراموش شده است چون در این حالت خطا مقدار خیلی زیادی میشود پس من خطا را با همان مقدار اولیه خروجی بررسی میکنم که برابر با 3419.2 بود درصد خطای این مقدار نسبت به مقدار m که در صورت سوال عدد 3000 گفته شده است حدود 14 درصد است چون طبق مقدار p و تعداد افراد که در صورت گزارش شده تعداد روابط تخمینی باید در حدود ضرب این دو عدد باشد که برابر 3400 است که کد ما که بر اساس همین روابط نوشته شده نیز عدد خیلی نزدیکی به آن گزارش کرده است که درصد خطای آن حدود نیم درصد است
#
# </p>

# # 18

# In[4]:


import numpy as np
import scipy.stats as st

graph = np.zeros(1000 * 1000).reshape(1000, 1000)

for k in range(10):
    for i in range(0, 1000):
        for j in range(0, 1000):
            if (j > i):
                p = st.bernoulli.rvs(0.00016)
                graph[i][j] = p
                graph[j][i] = p

# In[11]:


L_list = graph.sum(axis=1)
mean_L = np.mean(L_list)
same_color = 0
rosva = 0
for i in range(1000):
    if (L_list[i] > mean_L):
        same_color += 1
    else:
        rosva += 1
print(same_color)
print(rosva)

# In[20]:


import matplotlib.pyplot as plt

xArr = [0, 1, 2, 3, 4]
yArr = []
for i in range(5):
    yArr.append(np.count_nonzero(L_list == i))
plt.bar(xArr, yArr)
plt.xlabel("k")
plt.ylabel("number of people with k same intersts")
plt.show()

# <p dir="rtl">
# تعداد افراد هم سلیقه بدست آمده 127 است
# از نزولی بودن نمودار داده شده توسط کد میتوان فهمید که با زیاد شدن تعداد افراد مورد نظر برای هم سلیقه بودن با هم تعداد دفعات رخ داد این حالت کاهش می یابد که بدیهی هست احتمال اینکه یک فرد با یک یا دو نفر هم سلیقه باشد بسیار بیشتر است تا اینکه یک فرد سه یا چهار نفر هم سلیقه داشته باشد این نزولی بودن به شدتی است که ما در ماتریس تصافی ای که ساختیم اصلا فردی را نداریم که با 5 نفر یا بیشتر هم سلیقه بیشتر باشد و نهایت تعداد هم سلیقه یک فرد در این ماتریس 4 نفر است که از روی نمودار هم میتوان دید که با چه شیب زیادی تعداد افراد بر حسب تعداد هم سلیقه کاهش می یابد
#
#
# </p>

# # 19

# In[78]:


import numpy as np
import matplotlib.pyplot as plt

graph = np.zeros(3000 * 3000).reshape(3000, 3000)

for k in range(5):
    for i in range(0, 3000):
        for j in range(0, 3000):
            if (j > i):
                p = st.bernoulli.rvs(0.01)
                graph[i][j] = p
                graph[j][i] = p

    step = np.where(graph > 0, 0, 1)
    np.fill_diagonal(step, 0)
    temp1 = np.matmul(graph, graph)
    temp2 = np.multiply(graph, temp1)
    temp3 = np.multiply(step, temp1)
    zanjire = []
    D
    taragozari = []
    zanjire.append(np.sum(temp3) / 2)
    taragozari.append(np.sum(temp2) / 6)
print("mean taragozari    :    ", np.mean(taragozari))
print("mean zanjire    :    ", np.mean(zanjire))

# <p dir="rtl">
# همانطور که از خروجی کد مشخص است میانگین تعداد روابط دارای خاصیت تراگذری برابر 4642 و میانگین تعداد روابط دارای خاصیت زنجیره ای برابر 1355241 است که مشخص است تعداد روابطی که خاصیت زنجیره ای دارند به مراتب از تعداد روابطی که خاصیت تراگذری دارند بیشتر است
# انگار میتوان گفت که برقراری خاصیت تراگذری شرط بسیار سخت تری است تا برقراری شرط زنجیره ای
#
# </p>

# # 20

# In[73]:


import numpy as np
import scipy.stats as st

graph = np.zeros(1000 * 1000).reshape(1000, 1000)

for i in range(0, 1000):
    for j in range(0, 1000):
        if (j > i):
            p = st.bernoulli.rvs(0.003)
            graph[i][j] = p
            graph[j][i] = p

for i in range(1000):
    j_list = []
    for j in range(1000):
        if (graph[i][j] == 1):
            j_list.append(j)
    for k in j_list:
        k_list = graph.sum(axis=1)
sum(k_list) / len(k_list)

# # 21

# In[26]:


import networkx as nx
import numpy as np
import scipy.stats as st

graph = np.zeros(1000 * 1000).reshape(1000, 1000)

for k in range(10):
    for i in range(0, 1000):
        for j in range(0, 1000):
            if (j > i):
                p = st.bernoulli.rvs(0.0033)
                graph[i][j] = p
                graph[j][i] = p

# In[27]:


mygraph = nx.path_graph(n)
for i in range(0, 1000):
    for j in range(i, 1000):
        if (graph[i][j] == 1):
            mygraph.add_edge(i, j)

route = 0
for i in range(1000):
    for j in range(1000):
        route += nx.shortest_path_length(mygraph, i, j)
print(route / ((n - 1) * n))

# # 22

# In[33]:


import networkx as nx
import numpy as np
import scipy.stats as st

graph = np.zeros(1000 * 1000).reshape(1000, 1000)

max_list = []
for k in range(100):
    for i in range(0, 50):
        for j in range(0, 50):
            if (j > i):
                p = st.bernoulli.rvs(0.34)
                graph[i][j] = p
                graph[j][i] = p
    mygraph = nx.path_graph(50)
    for i in range(0, 50):
        for j in range(i, 50):
            if (graph[i][j] == 1):
                mygraph.add_edge(i, j)
    maxRoute = 0
    for i in range(50):
        for j in range(50):
            if (nx.shortest_path_length(mygraph, i, j) > maxRoute):
                maxRoute = nx.shortest_path_length(mygraph, i, j)
    max_list.append(maxRoute)
mean_max = sum(max_list) / 100
mean_max

# # 23

# In[1]:


import networkx as nx
import numpy as np
import scipy.stats as st

graph = np.zeros(1000 * 1000).reshape(1000, 1000)

maxes_n = []
for n in range(10, 201, 10):
    max_list = []
    for k in range(100):
        for i in range(0, n):
            for j in range(0, n):
                if (j > i):
                    p = st.bernoulli.rvs(0.34)
                    graph[i][j] = p
                    graph[j][i] = p
        mygraph = nx.path_graph(n)
        for i in range(0, n):
            for j in range(i, n):
                if (graph[i][j] == 1):
                    mygraph.add_edge(i, j)
        maxRoute = 0
        for i in range(n):
            for j in range(n):
                if (nx.shortest_path_length(mygraph, i, j) > maxRoute):
                    maxRoute = nx.shortest_path_length(mygraph, i, j)
        max_list.append(maxRoute)
    mean_max = sum(max_list) / len(max_list)
    maxes_n.append(mean_max)

# In[3]:


import matplotlib.pyplot as plt

n_list = [i for i in range(10, 201, 10)]
plt.bar(n_list, maxes_n)

# <p dir="rtl">
# در چند مرحله اول ابتدا نمودار به صورت صعودی هست و سپس نزولی میشود دلیل این تغییرات هم این است که با افزایش مقدار n طبیعی است که میانگین فاصله افراد زیاد شود ولی چون در میانگین گیری n در مخرج ظاهر میشود پس از یک مقدار بزرگ شدن n نمودار به صورت نزولی شدن میرود و در ادامه تغییرات آن خیلی کند میشود (در مقادیر بزرگ n )
#
#
# </p>

# # 24

# In[60]:


import numpy as np
import scipy.stats as st

graph = np.zeros(1000 * 1000).reshape(1000, 1000)

tri_list = []

for k in range(100):
    for i in range(0, 100):
        for j in range(0, 100):
            if (j > i):
                p = st.bernoulli.rvs(0.34)
                graph[i][j] = p
                graph[j][i] = p
    tri = 0
    for i in range(100):
        for j in range(i + 1, 100):
            if (graph[i][j] == 1):
                for l in range(j + 1, 100):
                    if (graph[i][l] == 1):
                        if (graph[j][l] == 1):
                            tri += 1
    tri_list.append(tri)

# In[62]:


sum(tri_list) / len(tri_list)

# # 25

# In[63]:


import numpy as np
import scipy.stats as st

graph = np.zeros(1000 * 1000).reshape(1000, 1000)

meanTri_list = []

for n in range(10, 101, 10):
    tri_list = []
    for k in range(100):
        for i in range(0, n):
            for j in range(0, n):
                if (j > i):
                    p = st.bernoulli.rvs(60 / (n * n))
                    graph[i][j] = p
                    graph[j][i] = p
        tri = 0
        for i in range(100):
            for j in range(i + 1, 100):
                if (graph[i][j] == 1):
                    for l in range(j + 1, 100):
                        if (graph[i][l] == 1):
                            if (graph[j][l] == 1):
                                tri += 1
        tri_list.append(tri)
        temp = sum(tri_list) / len(tri_list)
    meanTri_list.append(temp)

# In[64]:


meanTri_list

# In[68]:


n_list = [i for i in range(10, 101, 10)]
plt.bar(n_list, meanTri_list)

# <p dir="rtl">
# با افزایش مقدار n به سرعت نمودار ما به 0 میل میکند
# چون مقدار p با عکس n به توان 2 رابطه دارد و با افزایش مقدار n مقدار p به سرعت به صفر میرود
# و نتیجه کاهش اساسی مقدار p این است که احتمال تشکیل یال بین هر دو راس i و j کاهش می یابد و وقتی احتمال تشکیل یال کاهش یابد نتیجه آن کاهش اساسی احتمال تشکیل مثلث هم سلیقگی سه نفره است و به همین دلیل است که با افزایش مقدار n نمودار به سرعت به 0 میل میکند
#
# </p>

# # 26

# In[69]:


import numpy as np
import scipy.stats as st

graph = np.zeros(1000 * 1000).reshape(1000, 1000)

meanTri_list = []

for n in range(10, 101, 10):
    tri_list = []
    for k in range(100):
        for i in range(0, n):
            for j in range(0, n):
                if (j > i):
                    p = st.bernoulli.rvs(0.34)
                    graph[i][j] = p
                    graph[j][i] = p
        tri = 0
        for i in range(100):
            for j in range(i + 1, 100):
                if (graph[i][j] == 1):
                    for l in range(j + 1, 100):
                        if (graph[i][l] == 1):
                            if (graph[j][l] == 1):
                                tri += 1
        tri_list.append(tri)
        temp = sum(tri_list) / len(tri_list)
    meanTri_list.append(temp)

# In[70]:


meanTri_list

# In[71]:


n_list = [i for i in range(10, 101, 10)]
plt.bar(n_list, meanTri_list)

# <p dir="rtl">
# خیر مقدار نمودار به عدد خاصی میل نمیکند و با افزایش n افزایش پیدا میکند
# دلیل آن این است که ما احتمال p را ثابت کرده ایم و آن را مستقل از تغییرات n در نظر گرفتیم
# و چونکه هرچه تعداد افراد بیشتری داشته باشیم در حالتی که p مقدار ثابتی است احتمال اینکه مثلث دوستی داشته باشیم بیشتر است
# مانند اینکه ما یک تاس را می اندازیم و میخواهیم مشاهده کنیم که دو عدد یکسان دیده شود بدیهی است که اگر احتمال امدن اعداد در پرتاب ها برابر باشد ما هرچه دفعات بیشتری تاس بیندازیم احتمالا دیده شدن دو عدد یکسان بیشتر است
# در اینجا نیز مانند مثال تاس با افزایش دفعات احتمال دیده شدن مثلث هم سلیقگی افزایش می یابد
#
# </p>

# # 27

# In[14]:


import numpy as np
import scipy.stats as st
import matplotlib.pyplot as plt

graph = np.zeros(1201 * 1201).reshape(1201, 1201)

meanTri_list = []

for n in range(50, 1201, 50):
    tri_list = []
    for i in range(0, n):
        for j in range(0, n):
            if (j > i):
                p = st.bernoulli.rvs(1 / n)
                graph[i][j] = p
                graph[j][i] = p
    tri = 0
    for i in range(n):
        for j in range(i + 1, n):
            if (graph[i][j] == 1):
                for l in range(j + 1, n):
                    if (graph[i][l] == 1):
                        if (graph[j][l] == 1):
                            tri += 1
        # tri_list.append(tri)
        # temp = sum(tri_list)/len(tri_list)
    meanTri_list.append(tri)

n_list = [i for i in range(50, 1201, 50)]
plt.scatter(n_list, meanTri_list)

# In[20]:


cdf = []
sumcdf = 0
for i in range(len(n_list)):
    sumcdf += meanTri_list[i]
    cdf.append(sumcdf)

cdf

# In[21]:


plt.plot(n_list, cdf)

# <p dir="rtl">
# در این مثال مقدار آن به 8 میل میکند ولی با چندبار ران کردن کد متوجه میشویم که این مقدار مختص این مثال است و با ساخت دوباره ماتریس و گراف تصادفی این عدد تغییر میکند و برابر با مجموع اعداد غیر صفر بدست امده در بخش اول سوال 27 است
#
# </p>

# In[ ]:






